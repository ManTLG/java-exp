public class ExceptionClass {
    
}
